from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
import datetime
import time


from .models import Number


# Create your views here.

#  添加账号
def add_number(request):

    if request.method == "GET":

        # 返回 add 账号页面
        return render(request,"hao/add_number.html")


    elif request.method == "POST":

        try:

            #  获取 number sex remarks
            number = str(request.POST.get("number"))

            sex = str(request.POST.get("Sex"))

            remarks = str(request.POST.get("remarks"))

            # print(number , sex ,remarks)
            # print(request.POST)

            now = datetime.datetime.now()

            #  添加到数据库
            Number.objects.create(number = number, channl=sex , remarks = now)


        except Exception as e:

            print(e)
            return HttpResponse("error")

        #  302  跳转
        return HttpResponseRedirect("/hao/add")

def IOS(request):


    if request.method == "GET":


        try:

            #  读取到 IOS 所有 数据
            list = Number.objects.filter(channl="IOS")

            # 可以出租的
            true = []

            # 不可以出租的
            false = []

            for i in list:
                # print(i, i.number, i.channl , i.deadline)


                # deadline(存储时间) +  rent(租赁时间)   =  到期时间  （UTC）

                i.deadline = i.deadline + datetime.timedelta(hours=i.rent)


                # 到期时间
                a = i.remarks

                now = str(datetime.datetime.now())

                # 每一条数据
                hao = {}
                hao["账号"] = i.number
                hao["时间"] =  i.remarks[0:16]
                hao["租赁"] = i.rent
                hao["a"] = a
                hao["id"] = i.id
                hao["count"] = int(i.count)
                hao["goods"] = i.goods

                # hao = []
                # hao.append(i.number)
                # hao.append(i.deadline)
                # hao.append(i.rent)
                # hao.append(a)
                # hao.append(i.id)

                #  对比到期时间  和   当前时间
                if a < now :
                    #   到期的
                    true.append(hao)
                    # if i.rent > 0:
                    #     # 到时间之后自动清零
                    #     this = Number.objects.get(id=hao["id"])
                    #     this.rent = 0
                    #     this.save()

                    # print("可以" , i.deadline)
                #
                else :
                    # 没到期的
                    # print("不可以" , i.deadline)
                    false.append(hao)
            #  排序
            true.sort(key=lambda x:x["a"])
            false.sort(key=lambda x:x["a"])

            # print(true)
            # print(false)

            # 返回页面
            return render(request, "hao/IOS.html", locals())
        except Exception as e:
            print(e)
            return HttpResponse("error")

    elif request.method == "POST":

        try:
            now = datetime.datetime.now()

            hour = request.POST.get('hour')
            id = request.POST.get('id')


            this = Number.objects.get(id=id)

            this.count = int(this.count) + 1

            this.rent = hour

            dao = now + datetime.timedelta(hours=int(hour))

            # 送5分钟
            if int(hour) > 0:
                dao = dao + datetime.timedelta(minutes=5)

            dao = dao.strftime('%Y-%m-%d %H:%M:%S')

            this.remarks = dao

            this.save()

            # print(now)
            # print(type(now))
            # print(len(str(now)))

            today = datetime.date.today()

            # print(today)
            # print(this.number, this.channl, now, hour)
            # 写入日志 并且创建今天的文本
            with open(f"日志/{today}.txt", "a", encoding="utf-8") as f:

                f.writelines(f"{this.number}  ,{this.channl}  ,{now}  ,{hour}\n")

            return HttpResponseRedirect("/hao/IOS")

        except Exception as e :
            print(e)

            return HttpResponseRedirect("/hao/IOS")

def Andorid(request):

    if request.method == "GET":

        try:
            list = Number.objects.filter(channl="Android")

            # 可以出租的
            true = []

            # 不可以出租的
            false = []

            for i in list:
                # print(i, i.number, i.channl , i.deadline)

                # i.deadline = i.deadline + datetime.timedelta(hours=i.rent)
                # a = str(i.deadline)
                a = i.remarks


                now = str(datetime.datetime.now())

                hao = {}
                hao["账号"] = i.number
                hao["时间"] = i.remarks[0:16]
                hao["租赁"] = i.rent
                hao["a"] = a
                hao["id"] = i.id
                hao["count"] = int(i.count)
                hao["goods"] = i.goods
                hao["密码"] = i.pin

                # hao = []
                # hao.append(i.number)
                # hao.append(i.deadline)
                # hao.append(i.rent)
                # hao.append(a)
                # hao.append(i.id)


                if a < now :

                    true.append(hao)

                    # if i.rent > 0 :
                    #
                    #     # 到时间之后自动清零
                    #     this = Number.objects.get(id=hao["id"])
                    #     this .rent = 0
                    #     this.save()

                    # print("可以" , i.deadline)
                #
                else :

                    # print("不可以" , i.deadline)
                    false.append(hao)

            true.sort(key=lambda x:x["a"])
            false.sort(key=lambda x:x["a"])

            # print(true)
            # print(false)

            return render(request, "hao/Android.html", locals())
        except Exception as e:
            print(e)
            return HttpResponse("error")

    elif request.method == "POST":

        try:

            now = datetime.datetime.now()

            hour = request.POST.get('hour')
            id = request.POST.get('id')


            this = Number.objects.get(id=id)

            this.count = int(this.count) + 1

            this.rent = hour

            dao = now + datetime.timedelta(hours= int(hour))

            # 送5分钟
            if int(hour) > 0 :
                dao = dao + datetime.timedelta(minutes=5)


            dao = dao.strftime('%Y-%m-%d %H:%M:%S')


            this.remarks = dao

            # print(dao)

            this.save()


            # print(now)
            # print(type(now))
            # print(len(str(now)))

            today = datetime.date.today()

            # print(today)
            # print(this.number, this.channl, now, hour)
            with open(f"日志/{today}.txt", "a" ,encoding="utf-8") as f:

                f.writelines(f"{this.number}  ,{this.channl}  ,{now}  ,{hour}\n")

            return HttpResponseRedirect("/hao/Android")

        except Exception as e :
            print(e)

            return HttpResponseRedirect("/hao/Android")


def settings(request):

    try:
        #  GET 返回页面
        if request.method == "GET":

            return render(request, "hao/settings.html")

        elif request.method == "POST":
            # POST  返回页面

            # 获取setting的值
            setting = request.POST.get("setting")

            # 如果是 clear_time  则执行这个
            if setting == "clear_time":

                this = Number.objects.all()

                for i in this:

                    i.count = 0

                    i.save()


            return render(request,"hao/settings.html")
    except Exception as e:

        print(e)

        return HttpResponse("error")



def num(request):



    if request.method == "GET":
        try:
            num = request.GET.get("num")
            I = Number.objects.get(id=num)
            time = I.remarks

            # 2022-06-13 14:51:32.569701

            Y = time[0:4]
            M = time[5:7]
            D = time[8:10]
            h = time[11:13]
            m = time[14:16]
            s = time[17:19]
            # ss = time[20:]


            # print(Y,M,D,h,m,s)

            return render(request,"hao/hao.html" ,locals())
        except Exception as e :
            print(e)
            return HttpResponse("error")

    elif request.method == "POST":
        try :
            num = request.GET.get("num")
            I = Number.objects.get(id=num)
            time = I.remarks

            Y = request.POST.get("Y")
            M = request.POST.get("M")
            D = request.POST.get("D")
            h = request.POST.get("h")
            m = request.POST.get("m")
            s = request.POST.get("s")
            # ss = request.POST.get("SS")
            # print(Y ,M , D,h,m,s,ss)
            # print(Y ,M , D,h,m,s)


            # time = f"{Y}-{M}-{D} {h}:{m}:{s}.000000"
            time = f"{Y}-{M}-{D} {h}:{m}:{s}"

            # print(time)

            I.remarks = time

            I.save()

            if I.channl == 'IOS':
                return HttpResponseRedirect("/hao/IOS")
            elif I.channl == "Android":
                return HttpResponseRedirect("/hao/Android")
        except Exception as e :
            print(e)
            return HttpResponse('error')


def goods(request):
    try:

        if request.method == "POST":

            id = request.GET.get("num")
            # print(id)
            goods = request.POST.get("goods")
            # print(goods)
            I = Number.objects.get(id=id)
            I.goods = goods

            # print(id)

            I.save()

            if I.channl == 'IOS':
                return HttpResponseRedirect("/hao/IOS")
            elif I.channl == "Android":
                return HttpResponseRedirect("/hao/Android")
    except Exception as e:
        print(e)
        return HttpResponse('error')



def pin(request):
    try:

        if request.method == "POST":

            id = request.GET.get("num")
            # print(id)
            pin = request.POST.get("pin")
            # print(pid)
            I = Number.objects.get(id=id)

            I.pin = pin

            # print(id,pin)

            I.save()

            if I.channl == 'IOS':
                return HttpResponseRedirect("/hao/IOS")
            elif I.channl == "Android":
                return HttpResponseRedirect("/hao/Android")
    except Exception as e:
        print(e)
        return HttpResponse('error')



def delete(request):
    try:
        if request.method == "POST":

            id = request.POST.get("id")

            I = Number.objects.get(id=id)

            # print(id)

            I.delete()

            if I.channl == 'IOS':
                return HttpResponseRedirect("/hao/IOS")
            elif I.channl == "Android":
                return HttpResponseRedirect("/hao/Android")
    except Exception as e:
        print(e)
        return HttpResponse('error')