
from django.urls import path ,include
from . import views

urlpatterns = [
    path("add" , views.add_number),
    path("Android" , views.Andorid),
    path("IOS" , views.IOS),
    path("settings",views.settings),
    path("num" , views.num),
    path("goods", views.goods),
    path("pin", views.pin),
    path("delete",views.delete),


]