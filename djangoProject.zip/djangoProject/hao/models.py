from django.db import models

# Create your models here.


class Number(models.Model):

    # 账号（手机号 or 邮箱）
    number = models.CharField("number",max_length=30)

    # 区（ IOS　安卓）
    channl = models.CharField("channl" , max_length=10)


    # 创建时间
    CreateTime = models.DateTimeField("CreateTime" , auto_now_add=True)

    # 更新时间  +  租赁时间 (非 亚洲时区) 时间 比正常时间少一些
    deadline = models.DateTimeField("deadline" , auto_now= True )

#     租赁时间
    rent = models.IntegerField("rent" , default= 0)

#     租赁次数
    count = models.IntegerField('count',default = 0)

#     备注
    remarks = models.CharField("remarks" ,max_length=30, default="")

#     物品
    goods = models.CharField("goods" ,max_length=200 , default="")

#     密码
    pin = models.CharField("pin" , max_length = 32 , default='')


