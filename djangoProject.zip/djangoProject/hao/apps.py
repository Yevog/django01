from django.apps import AppConfig


class HaoConfig(AppConfig):
    name = 'hao'
