-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: zuhao
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add number',7,'add_number'),(26,'Can change number',7,'change_number'),(27,'Can delete number',7,'delete_number'),(28,'Can view number',7,'view_number');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(7,'hao','number'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2022-04-22 04:54:03.257567'),(2,'auth','0001_initial','2022-04-22 04:54:03.399949'),(3,'admin','0001_initial','2022-04-22 04:54:03.805295'),(4,'admin','0002_logentry_remove_auto_add','2022-04-22 04:54:03.901500'),(5,'admin','0003_logentry_add_action_flag_choices','2022-04-22 04:54:03.909674'),(6,'contenttypes','0002_remove_content_type_name','2022-04-22 04:54:04.002035'),(7,'auth','0002_alter_permission_name_max_length','2022-04-22 04:54:04.053720'),(8,'auth','0003_alter_user_email_max_length','2022-04-22 04:54:04.111480'),(9,'auth','0004_alter_user_username_opts','2022-04-22 04:54:04.119077'),(10,'auth','0005_alter_user_last_login_null','2022-04-22 04:54:04.168539'),(11,'auth','0006_require_contenttypes_0002','2022-04-22 04:54:04.171583'),(12,'auth','0007_alter_validators_add_error_messages','2022-04-22 04:54:04.180027'),(13,'auth','0008_alter_user_username_max_length','2022-04-22 04:54:04.234066'),(14,'auth','0009_alter_user_last_name_max_length','2022-04-22 04:54:04.287537'),(15,'auth','0010_alter_group_name_max_length','2022-04-22 04:54:04.336821'),(16,'auth','0011_update_proxy_permissions','2022-04-22 04:54:04.345557'),(17,'auth','0012_alter_user_first_name_max_length','2022-04-22 04:54:04.404644'),(18,'hao','0001_initial','2022-04-22 04:54:04.430030'),(19,'sessions','0001_initial','2022-04-22 04:54:04.454792'),(20,'hao','0002_auto_20220422_1343','2022-04-22 05:43:25.096868'),(21,'hao','0003_auto_20220422_1403','2022-04-22 06:03:47.952279'),(22,'hao','0004_auto_20220422_1405','2022-04-22 06:05:52.287828'),(23,'hao','0005_auto_20220422_1414','2022-04-22 06:14:19.618386'),(24,'hao','0006_auto_20220422_1415','2022-04-22 06:15:13.777358'),(25,'hao','0007_number_count','2022-04-26 01:20:20.929550'),(26,'hao','0008_auto_20220502_0823','2022-05-02 00:24:14.704116'),(27,'hao','0009_number_goods','2022-07-22 01:50:50.985148'),(28,'hao','0010_number_pin','2022-07-29 03:06:51.292849');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hao_number`
--

DROP TABLE IF EXISTS `hao_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hao_number` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` varchar(30) NOT NULL,
  `channl` varchar(10) NOT NULL,
  `CreateTime` datetime(6) NOT NULL,
  `deadline` datetime(6) NOT NULL,
  `remarks` varchar(30) NOT NULL,
  `rent` int NOT NULL,
  `count` int NOT NULL,
  `goods` varchar(200) NOT NULL,
  `pin` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hao_number`
--

LOCK TABLES `hao_number` WRITE;
/*!40000 ALTER TABLE `hao_number` DISABLE KEYS */;
INSERT INTO `hao_number` VALUES (20,'2199138967@qq.com','IOS','2022-04-24 12:16:43.010449','2022-11-05 04:11:50.694584','2022-11-05 14:16:50',2,20,'白鸟 蝙蝠 耳坠',''),(21,'kkcf1456@163.com','IOS','2022-04-24 12:16:59.505121','2022-11-04 00:30:18.515246','2022-11-10 23:02:40',168,15,'白鸟 蝙蝠','789456ss'),(22,'861845587@qq.com','IOS','2022-04-24 12:17:12.057615','2022-11-05 04:30:36.499094','2022-11-05 13:35:36',1,22,'白鸟 耳坠 蝙蝠','789456ss'),(23,'ayao0vo@163.com','IOS','2022-04-24 12:17:17.836696','2022-11-05 04:29:25.909715','2022-11-05 13:34:25',1,20,'白鸟 蝙蝠','789456ss'),(24,'z1063497506@163.com','IOS','2022-04-24 12:17:24.174697','2022-11-05 04:10:59.004719','2022-11-05 13:15:59',1,24,'白鸟 蝙蝠 耳坠','789456ss'),(26,'hewo19870519@163.com','IOS','2022-04-24 12:17:36.443076','2022-11-05 04:19:21.123912','2022-11-05 13:48:25',1,21,'白鸟 耳坠 蝙蝠',''),(28,'worinige233yeyou@163.com','IOS','2022-04-24 12:17:47.174617','2022-11-05 04:10:03.924784','2022-11-05 13:15:03',1,24,'白鸟 耳坠 蝙蝠',''),(29,'2321602260@qq.com','IOS','2022-04-24 12:17:52.116853','2022-11-05 03:41:19.355935','2022-11-05 12:46:19',1,19,'白鸟 蝙蝠',''),(30,'xiaohuanhuanmoje@126.com','IOS','2022-04-24 12:17:56.468818','2022-11-05 04:23:05.842345','2022-11-05 13:28:05',1,21,'白鸟 耳坠 蝙蝠斗',''),(33,'13171503360','IOS','2022-04-24 12:18:11.876510','2022-11-03 14:00:01.448065','2022-11-06 22:05:01',72,4,'白鸟 耳坠 蝙蝠',''),(34,'13091075967','IOS','2022-04-24 12:18:16.069733','2022-11-05 05:10:41.526888','2022-11-05 14:15:41',1,25,'白鸟 耳坠 蝙蝠','789456ss'),(35,'13313295976','IOS','2022-04-24 12:18:22.249427','2022-11-05 05:04:39.609346','2022-11-05 14:09:39',1,25,'白鸟 蝙蝠',''),(36,'13373556067','IOS','2022-04-24 12:18:26.394015','2022-11-05 04:09:09.119781','2022-11-05 13:14:09',1,15,'白鸟 耳坠 蝙蝠',''),(37,'15226671550','IOS','2022-04-24 12:18:33.617948','2022-11-05 04:27:56.127471','2022-11-05 13:32:56',1,26,'白鸟 耳坠 蝙蝠',''),(38,'18931462144','IOS','2022-04-24 12:18:40.476527','2022-11-02 12:56:24.466918','2136-12-01 13:01:24',1000000,10,'白鸟 耳坠 蝙蝠',''),(39,'18831530360','IOS','2022-04-24 12:18:48.531340','2022-11-02 12:55:52.262863','2023-12-24 13:00:52',10000,6,'白鸟 耳坠 蝙蝠',''),(40,'14756518821','IOS','2022-04-24 12:18:53.668744','2022-11-05 03:29:54.723810','2022-11-05 13:34:54',2,25,'白鸟 耳坠 蝙蝠',''),(41,'13091075871','IOS','2022-04-24 12:18:58.028086','2022-11-05 03:33:06.886766','2022-11-05 13:38:06',2,30,'白鸟 耳坠',''),(42,'13091075091','IOS','2022-04-24 12:20:03.634445','2022-11-05 05:14:31.615791','2022-11-05 14:19:31',1,25,'白鸟 耳坠 蝙蝠',''),(43,'15533576272','IOS','2022-04-24 12:20:08.386260','2022-11-05 05:04:53.001758','2022-11-05 14:09:52',1,22,'白鸟 耳坠 蝙蝠',''),(44,'18831530072','IOS','2022-04-24 12:20:13.071799','2022-11-05 04:27:21.347081','2022-11-05 13:32:21',1,24,'白鸟 耳坠 蝙蝠',''),(45,'13091075926','IOS','2022-04-24 12:20:19.242472','2022-11-05 02:53:41.125090','2022-11-05 12:58:41',2,20,'白鸟 蝙蝠 ',''),(46,'18831530027','IOS','2022-04-24 12:20:24.604824','2022-11-05 04:19:29.871308','2022-11-05 13:24:29',1,20,'白鸟 耳坠 蝙蝠 伴爱 小王子',''),(47,'18831530031','IOS','2022-04-24 12:20:32.046898','2022-11-05 04:52:42.543972','2022-11-05 13:57:42',1,26,'白鸟 耳坠 蝙蝠',''),(49,'15533461303','Android','2022-04-24 12:20:56.430081','2022-11-05 03:17:20.155635','2022-11-05 12:22:20',1,26,'耳坠 蝙蝠',''),(50,'13383159052','Android','2022-04-24 12:21:00.352139','2022-11-05 04:04:33.071363','2022-11-05 13:09:33',1,19,'蝙蝠 耳坠',''),(51,'13363280870','Android','2022-04-24 12:21:03.795498','2022-11-05 03:55:26.111676','2022-11-05 13:00:26',1,19,'耳坠 蝙蝠',''),(52,'tan121428@163.com','Android','2022-04-24 12:21:07.504890','2022-11-05 03:53:11.848066','2022-11-05 13:58:11',2,24,'耳坠 蝙蝠',''),(53,'jjlin3273271307@163.com','Android','2022-04-24 12:21:10.800259','2022-11-05 03:52:12.759003','2022-11-05 12:57:12',1,23,'耳坠 （高）',''),(54,'zxy121399@163.com','Android','2022-04-24 12:21:13.856869','2022-11-05 03:12:27.241459','2022-11-05 12:17:27',1,19,'耳坠 蝙蝠',''),(56,'yhyh357@163.com','Android','2022-04-24 12:21:20.161986','2022-11-05 03:40:13.306370','2022-11-05 12:45:13',1,20,'耳坠 蝙蝠',''),(57,'fengjia473730@163.com','Android','2022-04-24 12:21:28.853881','2022-11-05 04:48:23.406272','2022-11-05 13:49:45',2,18,'蝙蝠 （高）',''),(58,'a874026965@163.com','Android','2022-04-24 12:21:32.179439','2022-11-05 05:12:36.173820','2022-11-05 14:17:36',1,19,'蝙蝠 （高）',''),(59,'haoxinyue0213@163.com','Android','2022-04-24 12:21:35.887410','2022-11-05 03:33:22.241828','2022-11-05 13:38:22',2,18,'蝙蝠 （高）',''),(60,'misaki1520@163.com','Android','2022-04-24 12:21:40.431871','2022-10-31 00:08:20.672733','2188-07-06 20:46:44',1452365,0,'蝙蝠 （高）',''),(61,'a2631858202@163.com','Android','2022-04-24 12:21:45.488553','2022-11-05 05:15:18.423341','2022-11-05 13:15:18',0,24,'蝙蝠 （高）','123456zxc'),(62,'jck15786@163.com','Android','2022-04-24 12:21:49.644603','2022-11-05 04:42:54.641898','2022-11-05 14:47:54',2,23,'白枭 蝙蝠 (高)',''),(64,'13363249267','IOS','2022-05-28 07:18:34.363293','2022-11-05 04:16:33.340092','2022-11-05 13:21:33',1,16,'白鸟 白枭 耳坠 蝙蝠',''),(69,'15533450591','IOS','2022-06-16 08:32:19.764737','2022-11-05 04:44:02.967243','2022-11-05 13:49:02',1,35,'白鸟 耳坠',''),(73,'17334949653','IOS','2022-06-27 08:45:13.994756','2022-11-05 02:58:44.183360','2022-11-05 13:03:44',2,22,'白鸟 耳坠 蝙蝠',''),(74,'lzbnjf7715@163.com','IOS','2022-07-02 07:34:03.125332','2022-11-05 04:16:12.051268','2022-11-05 13:21:12',1,45,'耳坠 蝙蝠 （高）',''),(88,'slzx20041125@163.com','IOS','2022-07-15 06:50:36.218369','2022-10-31 00:08:20.686953','2023-11-25 08:32:16',10000,0,'绊爱 白枭  （中）',''),(89,'tfllg719415@163.com','Android','2022-07-23 05:52:30.604333','2022-11-05 05:16:19.968308','2022-11-05 14:21:19',1,31,'武士裤 伴爱 雪花 （中）',''),(90,'qianjia19790317@163.com','Android','2022-07-23 05:57:26.175379','2022-11-05 04:12:56.712500','2022-11-05 13:17:56',1,16,'耳坠 蝙蝠 阿努比斯 围巾',''),(92,'nlllr7@163.com','IOS','2022-07-24 12:35:11.244599','2022-11-04 13:04:11.586650','2022-11-05 21:09:11',24,27,'巫师  （中）',''),(93,'243477172@qq.com','Android','2022-07-25 07:25:46.227463','2022-11-05 04:12:39.759531','2022-11-05 13:17:39',1,15,'蝙蝠 绊爱 巫师 （高）',''),(94,'vlsp83@163.com','Android','2022-07-28 15:23:36.521961','2022-11-05 02:42:25.709107','2022-11-05 12:47:25',2,32,'绊爱 三季节 （中）',''),(96,'13513050182','IOS','2022-08-07 03:19:12.119712','2022-11-05 04:05:56.758587','2022-11-05 13:10:56',1,26,'白鸟 耳坠 蝙蝠 ',''),(97,'m15190904186_2@163.com','Android','2022-08-07 09:05:28.493746','2022-11-05 03:46:13.749204','2022-11-05 12:51:13',1,20,'耳坠 蝙蝠',''),(98,'14756519181','IOS','2022-10-25 05:57:19.890968','2022-11-05 03:58:17.021867','2022-11-05 13:03:17',1,27,'白鸟 蝙蝠斗 耳坠 ','');
/*!40000 ALTER TABLE `hao_number` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-05 13:17:00
